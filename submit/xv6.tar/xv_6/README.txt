GROUP MEMBERS: Richard Tran, Alex Zhang

Yes. We did the optional assignment.
---------------------------------
Implentation:
Trace: 
We added isTrace and numOfCalls to the struct to proc.h, in which isTrace is a boolean. 0=OFF; 1=ON.
numOfCalls starts at 0, then increments every call to a system call from user.h. 

We print out the information of every process and syscall when trace(1) is on, within syscall method in syscall.c
syscall(void) checks if isTrace equals 1, and prints out the incoming system call, and increments numOfCalls. If it equals 0, then ignore printing.

Lastly, if trace(0) is called, we print out numOfCalls.

Returns:
   Number of syscalls made within current process
----------------------------------------------------------
CSINFO:

After further observation of the syscall sleep(), we realized that the swtch() method was being called to do the context switching. Therefore, we added a variable to proc.h in struct proc called numCsInfo to track the number of times swtch() was being called in the method sched() in proc.c.

-------------------------------------------------------------------

Within our test program, "trace.c", we tested both csInfo and trace within the same program just to save ourselves time.
We made trace count every syscall made within the program using sleep, since sleep is a system call itself,
and then printed out the amount of context switches that happened. As a result, we can see how many context switches that
happened, and we can manually count and compare the test program's desired amount of syscalls to the actual count.

-----------------------------------------

In the make file, we added _trace so that we can call "trace" as soon as we call make qemu-nox to run our trace.c program.

In short: Run "trace" in "make qemu-nox" to run our test program